module Task3 {
}